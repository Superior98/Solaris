fill 60 182 273 60 182 297 minecraft:polished_blackstone
fill 60 185 273 60 185 297 minecraft:polished_blackstone
fill 60 188 273 60 188 297 minecraft:polished_blackstone
scoreboard players set #t organ 0
scoreboard players set #on organ 1
title @a[x=20,y=160,z=261,dx=60,dy=50,dz=50] actionbar {"text":"♪ Now playing: An Ending – Fireheart_4743 ♪","color":"light_purple"}
