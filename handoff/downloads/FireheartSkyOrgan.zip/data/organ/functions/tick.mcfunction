execute if block 53 181 283 minecraft:warped_button[powered=true] unless score #pb organ matches 1 run function organ:play
execute store success score #pb organ if block 53 181 283 minecraft:warped_button[powered=true]
execute if block 53 181 287 minecraft:crimson_button[powered=true] unless score #sb organ matches 1 run function organ:stop
execute store success score #sb organ if block 53 181 287 minecraft:crimson_button[powered=true]
execute if score #on organ matches 1 run function organ:step
