fill 60 182 273 60 182 297 minecraft:polished_blackstone
fill 60 185 273 60 185 297 minecraft:polished_blackstone
fill 60 188 273 60 188 297 minecraft:polished_blackstone
scoreboard players set #on organ 0
title @a[x=20,y=160,z=261,dx=60,dy=50,dz=50] actionbar {"text":"♪ Thanks for listening ♪","color":"aqua"}
