scoreboard objectives add organ dummy
scoreboard players add #on organ 0
scoreboard players add #pb organ 0
scoreboard players add #sb organ 0
