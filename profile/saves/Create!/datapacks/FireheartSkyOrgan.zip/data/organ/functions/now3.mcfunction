title @a[x=20,y=160,z=261,dx=60,dy=50,dz=50] actionbar {"text":"♪ Now playing: Finale ♪","color":"light_purple"}
