execute if score #t organ matches 3003 run setblock 60 185 276 minecraft:redstone_block
execute if score #t organ matches 3005 run setblock 60 185 276 minecraft:polished_blackstone
execute if score #t organ matches 3012 run setblock 60 185 276 minecraft:redstone_block
execute if score #t organ matches 3014 run setblock 60 185 276 minecraft:polished_blackstone
