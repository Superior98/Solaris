scoreboard objectives add organ dummy
execute unless score #song organ matches 1.. run scoreboard players set #song organ 1
scoreboard players add #nb organ 0
scoreboard players add #on organ 0
scoreboard players add #pb organ 0
scoreboard players add #sb organ 0
