function organ:stop
scoreboard players add #song organ 1
execute if score #song organ matches 5.. run scoreboard players set #song organ 1
execute if score #song organ matches 1 run function organ:sel1
execute if score #song organ matches 2 run function organ:sel2
execute if score #song organ matches 3 run function organ:sel3
execute if score #song organ matches 4 run function organ:sel4
