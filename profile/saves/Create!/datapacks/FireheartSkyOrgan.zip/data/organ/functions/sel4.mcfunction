data merge block 53 182 285 {front_text:{color:"light_blue",has_glowing_text:1b,messages:['"SKY ORGAN"','"♪ Frozen Time ♪"','"Song 4/4"','"▼ next song"']}}
title @a[x=20,y=160,z=261,dx=60,dy=50,dz=50] actionbar {"text":"Selected: Frozen Time – press ▶ PLAY","color":"aqua"}
