fill 60 182 273 60 182 297 minecraft:polished_blackstone
fill 60 185 273 60 185 297 minecraft:polished_blackstone
fill 60 188 273 60 188 297 minecraft:polished_blackstone
scoreboard players set #t organ 0
scoreboard players set #on organ 1
execute if score #song organ matches 1 run function organ:now1
execute if score #song organ matches 2 run function organ:now2
execute if score #song organ matches 3 run function organ:now3
execute if score #song organ matches 4 run function organ:now4
