scoreboard players add #t organ 1
execute if score #song organ matches 1 run function organ:step1
execute if score #song organ matches 2 run function organ:step2
execute if score #song organ matches 3 run function organ:step3
execute if score #song organ matches 4 run function organ:step4
