data merge block 53 182 285 {front_text:{color:"light_blue",has_glowing_text:1b,messages:['"SKY ORGAN"','"♪ Fallen Down ♪"','"Song 2/4"','"▼ next song"']}}
title @a[x=20,y=160,z=261,dx=60,dy=50,dz=50] actionbar {"text":"Selected: Fallen Down – press ▶ PLAY","color":"aqua"}
