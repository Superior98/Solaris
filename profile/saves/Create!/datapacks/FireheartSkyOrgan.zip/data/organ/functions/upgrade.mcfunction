setblock 59 181 273 minecraft:dark_oak_planks
setblock 59 182 273 minecraft:note_block[instrument=bass,note=4,powered=false]
setblock 59 181 274 minecraft:birch_planks
setblock 59 182 274 minecraft:note_block[instrument=bass,note=5,powered=false]
setblock 59 181 275 minecraft:birch_planks
setblock 59 182 275 minecraft:note_block[instrument=bass,note=6,powered=false]
setblock 59 181 276 minecraft:dark_oak_planks
setblock 59 182 276 minecraft:note_block[instrument=bass,note=7,powered=false]
setblock 53 181 285 minecraft:polished_blackstone_button[face=wall,facing=west,powered=false]
function organ:load
function organ:stop
function organ:sel1
say ORGAN_UPGRADE_DONE
