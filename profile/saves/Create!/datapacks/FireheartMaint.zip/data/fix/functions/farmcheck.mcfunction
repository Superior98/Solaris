tellraw @a ["CHECK2 Farm engine = ",{"nbt":"Speed","block":"-5 71 -2"}]
tellraw @a ["CHECK2 Farm piston = ",{"nbt":"Speed","block":"-8 71 -2"}]
tellraw @a ["CHECK2 Belt press = ",{"nbt":"Speed","block":"3 73 6"}]
tellraw @a ["CHECK2 Bakery wheat = ",{"nbt":"Items[0]","block":"-28 75 4"}]
tellraw @a ["CHECK2 Ingots = ",{"nbt":"Items[0]","block":"0 73 6"}]
tellraw @a ["CHECK2 Gravel millstone = ",{"nbt":"Speed","block":"-36 73 54"}]
execute if entity @e[type=create:stationary_contraption,x=-7,y=71,z=0,distance=..12] run tellraw @a "CHECK2 farm frame moving"
say FARMCHECK_DONE
