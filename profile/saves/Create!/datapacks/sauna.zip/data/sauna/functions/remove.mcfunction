execute as @e[type=minecraft:marker,tag=sauna,sort=nearest,limit=1] at @s run fill ~2 ~ ~-6 ~19 ~12 ~6 minecraft:air
execute as @e[type=minecraft:marker,tag=sauna,sort=nearest,limit=1] at @s run fill ~2 ~-1 ~-6 ~19 ~-1 ~6 minecraft:grass_block
kill @e[type=minecraft:marker,tag=sauna,sort=nearest,limit=1]
tellraw @s {"text":"Nearest sauna removed.","color":"gray"}
