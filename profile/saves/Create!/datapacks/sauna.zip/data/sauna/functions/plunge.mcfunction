title @s actionbar {"text":"❄ Brrr! The cold plunge wakes you right up ❄","color":"aqua"}
execute at @s run particle minecraft:bubble_pop ~ ~1 ~ 0.4 0.3 0.4 0.02 4
effect give @s minecraft:speed 20 1 true
effect give @s minecraft:haste 20 0 true
