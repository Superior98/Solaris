execute if predicate sauna:c5 run particle minecraft:heart ~ ~2.1 ~ 0.2 0.1 0.2 0 1
