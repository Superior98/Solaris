execute as @e[type=minecraft:marker,tag=sauna] at @s run function sauna:amb
execute as @a[tag=sauna_in,tag=!sauna_now] run function sauna:leave
tag @a remove sauna_now
schedule function sauna:loop 10t replace
