tag @s add sauna_now
execute unless entity @s[tag=sauna_in] run playsound minecraft:music.overworld.cherry_grove record @s ~ ~ ~ 0.6 1
execute unless entity @s[tag=sauna_in] run title @s actionbar {"text":"♨ Welcome to Solaris Sauna. Take a deep breath...","color":"gold"}
tag @s add sauna_in
effect give @s minecraft:regeneration 4 0 true
