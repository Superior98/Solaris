kill @e[type=minecraft:marker,tag=sauna,distance=..2]
fill ~2 ~ ~-6 ~19 ~12 ~6 minecraft:air
fill ~2 ~-5 ~-6 ~19 ~-2 ~6 minecraft:dirt replace minecraft:air
fill ~2 ~-5 ~-6 ~19 ~-2 ~6 minecraft:dirt replace minecraft:water
fill ~2 ~-1 ~-6 ~19 ~-1 ~6 minecraft:grass_block
fill ~5 ~-1 ~-5 ~18 ~-1 ~5 minecraft:spruce_planks
fill ~5 ~ ~-5 ~18 ~4 ~-5 minecraft:spruce_log[axis=x]
fill ~5 ~ ~5 ~18 ~4 ~5 minecraft:spruce_log[axis=x]
fill ~5 ~ ~-5 ~5 ~4 ~5 minecraft:spruce_log[axis=z]
fill ~18 ~ ~-5 ~18 ~4 ~5 minecraft:spruce_log[axis=z]
fill ~5 ~-1 ~-5 ~5 ~5 ~-5 minecraft:stripped_dark_oak_log[axis=y]
fill ~5 ~-1 ~5 ~5 ~5 ~5 minecraft:stripped_dark_oak_log[axis=y]
fill ~18 ~-1 ~-5 ~18 ~5 ~-5 minecraft:stripped_dark_oak_log[axis=y]
fill ~18 ~-1 ~5 ~18 ~5 ~5 minecraft:stripped_dark_oak_log[axis=y]
fill ~6 ~5 ~-4 ~17 ~5 ~4 minecraft:spruce_planks
fill ~12 ~5 ~-4 ~17 ~5 ~4 minecraft:stripped_spruce_wood
fill ~6 ~5 ~-5 ~17 ~5 ~-5 minecraft:dark_oak_log[axis=x]
fill ~6 ~5 ~5 ~17 ~5 ~5 minecraft:dark_oak_log[axis=x]
fill ~5 ~5 ~-4 ~5 ~5 ~4 minecraft:dark_oak_log[axis=z]
fill ~18 ~5 ~-4 ~18 ~5 ~4 minecraft:dark_oak_log[axis=z]
fill ~11 ~ ~-4 ~11 ~4 ~4 minecraft:stripped_spruce_log[axis=z]
fill ~11 ~5 ~-4 ~11 ~5 ~4 minecraft:dark_oak_log[axis=z]
fill ~4 ~5 ~-6 ~19 ~5 ~-6 minecraft:dark_oak_stairs[facing=south]
fill ~4 ~5 ~6 ~19 ~5 ~6 minecraft:dark_oak_stairs[facing=north]
fill ~4 ~6 ~-5 ~19 ~6 ~-5 minecraft:dark_oak_stairs[facing=south]
fill ~4 ~6 ~5 ~19 ~6 ~5 minecraft:dark_oak_stairs[facing=north]
fill ~4 ~7 ~-4 ~19 ~7 ~-4 minecraft:dark_oak_stairs[facing=south]
fill ~4 ~7 ~4 ~19 ~7 ~4 minecraft:dark_oak_stairs[facing=north]
fill ~4 ~8 ~-3 ~19 ~8 ~-3 minecraft:dark_oak_stairs[facing=south]
fill ~4 ~8 ~3 ~19 ~8 ~3 minecraft:dark_oak_stairs[facing=north]
fill ~4 ~9 ~-2 ~19 ~9 ~-2 minecraft:dark_oak_stairs[facing=south]
fill ~4 ~9 ~2 ~19 ~9 ~2 minecraft:dark_oak_stairs[facing=north]
fill ~4 ~10 ~-1 ~19 ~10 ~-1 minecraft:dark_oak_stairs[facing=south]
fill ~4 ~10 ~1 ~19 ~10 ~1 minecraft:dark_oak_stairs[facing=north]
fill ~4 ~10 ~ ~19 ~10 ~ minecraft:dark_oak_planks
fill ~4 ~11 ~ ~19 ~11 ~ minecraft:dark_oak_slab[type=bottom]
fill ~5 ~6 ~-4 ~5 ~6 ~-4 minecraft:spruce_planks
fill ~5 ~6 ~4 ~5 ~6 ~4 minecraft:spruce_planks
fill ~5 ~6 ~3 ~5 ~7 ~3 minecraft:spruce_planks
fill ~5 ~6 ~-3 ~5 ~7 ~-3 minecraft:spruce_planks
fill ~5 ~6 ~2 ~5 ~8 ~2 minecraft:spruce_planks
fill ~5 ~6 ~-2 ~5 ~8 ~-2 minecraft:spruce_planks
fill ~5 ~6 ~-1 ~5 ~9 ~-1 minecraft:spruce_planks
fill ~5 ~6 ~1 ~5 ~9 ~1 minecraft:spruce_planks
fill ~5 ~6 ~ ~5 ~10 ~ minecraft:spruce_planks
setblock ~5 ~7 ~ minecraft:orange_stained_glass
setblock ~5 ~8 ~ minecraft:orange_stained_glass
fill ~18 ~6 ~-4 ~18 ~6 ~-4 minecraft:spruce_planks
fill ~18 ~6 ~4 ~18 ~6 ~4 minecraft:spruce_planks
fill ~18 ~6 ~3 ~18 ~7 ~3 minecraft:spruce_planks
fill ~18 ~6 ~-3 ~18 ~7 ~-3 minecraft:spruce_planks
fill ~18 ~6 ~2 ~18 ~8 ~2 minecraft:spruce_planks
fill ~18 ~6 ~-2 ~18 ~8 ~-2 minecraft:spruce_planks
fill ~18 ~6 ~-1 ~18 ~9 ~-1 minecraft:spruce_planks
fill ~18 ~6 ~1 ~18 ~9 ~1 minecraft:spruce_planks
fill ~18 ~6 ~ ~18 ~10 ~ minecraft:spruce_planks
setblock ~18 ~7 ~ minecraft:orange_stained_glass
setblock ~18 ~8 ~ minecraft:orange_stained_glass
fill ~7 ~1 ~-5 ~9 ~2 ~-5 minecraft:glass_pane[east=true,west=true,north=false,south=false]
fill ~7 ~1 ~5 ~9 ~2 ~5 minecraft:glass_pane[east=true,west=true,north=false,south=false]
fill ~14 ~2 ~5 ~15 ~2 ~5 minecraft:glass_pane[east=true,west=true,north=false,south=false]
fill ~5 ~1 ~-3 ~5 ~2 ~-2 minecraft:glass_pane[north=true,south=true,east=false,west=false]
fill ~5 ~1 ~2 ~5 ~2 ~3 minecraft:glass_pane[north=true,south=true,east=false,west=false]
fill ~11 ~1 ~-3 ~11 ~2 ~-2 minecraft:glass_pane[north=true,south=true,east=false,west=false]
fill ~11 ~1 ~2 ~11 ~2 ~3 minecraft:glass_pane[north=true,south=true,east=false,west=false]
fill ~18 ~2 ~-1 ~18 ~2 ~1 minecraft:glass_pane[north=true,south=true,east=false,west=false]
setblock ~5 ~ ~ minecraft:spruce_door[facing=east,half=lower,hinge=left]
setblock ~5 ~1 ~ minecraft:spruce_door[facing=east,half=upper,hinge=left]
setblock ~11 ~ ~ minecraft:spruce_door[facing=east,half=lower,hinge=left]
setblock ~11 ~1 ~ minecraft:spruce_door[facing=east,half=upper,hinge=left]
setblock ~8 ~-1 ~ minecraft:shroomlight
fill ~7 ~ ~-1 ~9 ~ ~2 minecraft:brown_carpet
fill ~8 ~ ~ ~8 ~ ~1 minecraft:orange_carpet
fill ~6 ~ ~-4 ~8 ~ ~-4 minecraft:spruce_stairs[facing=north]
fill ~6 ~ ~4 ~8 ~ ~4 minecraft:spruce_stairs[facing=south]
setblock ~7 ~ ~-3 minecraft:spruce_fence
setblock ~7 ~1 ~-3 minecraft:candle[candles=4,lit=true]
setblock ~7 ~ ~3 minecraft:spruce_fence
setblock ~7 ~1 ~3 minecraft:potted_flowering_azalea_bush
setblock ~9 ~ ~-4 minecraft:barrel[facing=up]{CustomName:'{"text":"Sauna Supplies"}',Items:[{Slot:0b,id:"minecraft:music_disc_mellohi",Count:1b},{Slot:1b,id:"minecraft:music_disc_otherside",Count:1b},{Slot:2b,id:"minecraft:music_disc_relic",Count:1b},{Slot:3b,id:"minecraft:music_disc_cat",Count:1b},{Slot:4b,id:"minecraft:honey_bottle",Count:6b},{Slot:5b,id:"minecraft:sweet_berries",Count:16b},{Slot:6b,id:"minecraft:cookie",Count:12b},{Slot:7b,id:"minecraft:white_wool",Count:8b}]}
setblock ~10 ~ ~-4 minecraft:barrel[facing=up]
setblock ~9 ~1 ~-4 minecraft:candle[candles=3,lit=true]
setblock ~10 ~1 ~-4 minecraft:white_carpet
setblock ~10 ~ ~-2 minecraft:jukebox
setblock ~10 ~1 ~-2 minecraft:potted_fern
setblock ~6 ~ ~-2 minecraft:potted_fern
setblock ~6 ~ ~2 minecraft:bookshelf
setblock ~6 ~1 ~2 minecraft:candle[candles=2,lit=true]
fill ~8 ~-3 ~2 ~11 ~-2 ~5 minecraft:stone_bricks
fill ~9 ~-3 ~3 ~10 ~-3 ~4 minecraft:sea_lantern
fill ~9 ~-2 ~3 ~10 ~-1 ~4 minecraft:water
setblock ~8 ~4 ~-2 minecraft:lantern[hanging=true]
setblock ~8 ~4 ~2 minecraft:lantern[hanging=true]
setblock ~6 ~2 ~1 minecraft:spruce_wall_sign[facing=east]{front_text:{color:"orange",has_glowing_text:1b,messages:['{"text": "Welcome to"}','{"text": "Solaris Sauna"}','{"text": "relax, breathe,"}','{"text": "unwind ♨"}']}}
setblock ~12 ~ ~-4 minecraft:blast_furnace[facing=south,lit=true]
setblock ~13 ~ ~-4 minecraft:blast_furnace[facing=south,lit=true]
setblock ~12 ~1 ~-4 minecraft:magma_block
setblock ~13 ~1 ~-4 minecraft:magma_block
setblock ~12 ~3 ~-4 minecraft:brick_wall[up=true]
fill ~12 ~4 ~-4 ~12 ~9 ~-4 minecraft:bricks
setblock ~12 ~10 ~-4 minecraft:campfire[lit=true,signal_fire=false,facing=south]
setblock ~14 ~ ~-4 minecraft:water_cauldron[level=3]
setblock ~14 ~1 ~-4 minecraft:spruce_button[face=wall,facing=south]
fill ~16 ~ ~-3 ~17 ~ ~4 minecraft:spruce_planks
fill ~16 ~1 ~-3 ~17 ~1 ~4 minecraft:spruce_slab[type=bottom]
fill ~15 ~ ~-3 ~15 ~ ~4 minecraft:spruce_slab[type=bottom]
fill ~12 ~ ~4 ~14 ~ ~4 minecraft:spruce_slab[type=bottom]
setblock ~17 ~ ~-4 minecraft:spruce_planks
setblock ~17 ~1 ~-4 minecraft:spruce_planks
setblock ~17 ~2 ~-4 minecraft:candle[candles=3,lit=true]
setblock ~16 ~ ~-4 minecraft:spruce_planks
setblock ~16 ~1 ~-4 minecraft:potted_fern
setblock ~14 ~4 ~-1 minecraft:lantern[hanging=true]
setblock ~14 ~4 ~2 minecraft:lantern[hanging=true]
setblock ~16 ~4 ~ minecraft:lantern[hanging=true]
setblock ~12 ~2 ~1 minecraft:spruce_wall_sign[facing=east]{front_text:{color:"orange",has_glowing_text:1b,messages:['{"text": "♨ 85°C ♨"}','{"text": "press the button"}','{"text": "to pour water"}','{"text": "on the stones"}']}}
fill ~2 ~-1 ~-4 ~4 ~-1 ~4 minecraft:spruce_planks
fill ~2 ~-1 ~-1 ~2 ~-1 ~1 minecraft:spruce_slab[type=top]
setblock ~2 ~ ~-4 minecraft:spruce_fence[north=false,south=true,east=true,west=false]
setblock ~2 ~ ~-3 minecraft:spruce_fence[north=true,south=true,east=false,west=false]
setblock ~2 ~ ~-2 minecraft:spruce_fence[north=true,south=false,east=false,west=false]
setblock ~2 ~ ~2 minecraft:spruce_fence[north=false,south=true,east=false,west=false]
setblock ~2 ~ ~3 minecraft:spruce_fence[north=true,south=true,east=false,west=false]
setblock ~2 ~ ~4 minecraft:spruce_fence[north=true,south=false,east=true,west=false]
setblock ~3 ~ ~-4 minecraft:spruce_fence[north=false,south=false,east=true,west=true]
setblock ~3 ~ ~4 minecraft:spruce_fence[north=false,south=false,east=true,west=true]
setblock ~4 ~ ~-4 minecraft:spruce_fence[north=false,south=false,east=true,west=true]
setblock ~4 ~ ~4 minecraft:spruce_fence[north=false,south=false,east=true,west=true]
setblock ~2 ~1 ~-4 minecraft:lantern
setblock ~2 ~1 ~4 minecraft:lantern
setblock ~2 ~1 ~-2 minecraft:lantern
setblock ~2 ~1 ~2 minecraft:lantern
fill ~4 ~ ~-3 ~4 ~ ~-2 minecraft:spruce_stairs[facing=east]
fill ~4 ~ ~2 ~4 ~ ~3 minecraft:spruce_stairs[facing=east]
setblock ~4 ~ ~-1 minecraft:potted_fern
setblock ~4 ~ ~1 minecraft:potted_fern
setblock ~4 ~2 ~ minecraft:spruce_wall_sign[facing=west]{front_text:{color:"orange",has_glowing_text:1b,messages:['{"text": "♨"}','{"text": "SOLARIS SAUNA"}','{"text": ""}','{"text": "open all day"}']}}
fill ~5 ~-1 ~-6 ~18 ~-1 ~-6 minecraft:moss_block
setblock ~5 ~ ~-6 minecraft:fern
setblock ~6 ~ ~-6 minecraft:flowering_azalea
setblock ~7 ~ ~-6 minecraft:large_fern[half=lower]
setblock ~7 ~1 ~-6 minecraft:large_fern[half=upper]
setblock ~8 ~ ~-6 minecraft:sweet_berry_bush[age=3]
setblock ~9 ~ ~-6 minecraft:azalea
setblock ~10 ~ ~-6 minecraft:fern
setblock ~11 ~ ~-6 minecraft:lily_of_the_valley
setblock ~12 ~ ~-6 minecraft:fern
setblock ~13 ~ ~-6 minecraft:flowering_azalea
setblock ~14 ~ ~-6 minecraft:large_fern[half=lower]
setblock ~14 ~1 ~-6 minecraft:large_fern[half=upper]
setblock ~15 ~ ~-6 minecraft:sweet_berry_bush[age=3]
setblock ~16 ~ ~-6 minecraft:azalea
setblock ~17 ~ ~-6 minecraft:fern
setblock ~18 ~ ~-6 minecraft:lily_of_the_valley
fill ~5 ~-1 ~6 ~18 ~-1 ~6 minecraft:moss_block
setblock ~5 ~ ~6 minecraft:fern
setblock ~6 ~ ~6 minecraft:flowering_azalea
setblock ~7 ~ ~6 minecraft:large_fern[half=lower]
setblock ~7 ~1 ~6 minecraft:large_fern[half=upper]
setblock ~8 ~ ~6 minecraft:sweet_berry_bush[age=3]
setblock ~9 ~ ~6 minecraft:azalea
setblock ~10 ~ ~6 minecraft:fern
setblock ~11 ~ ~6 minecraft:lily_of_the_valley
setblock ~12 ~ ~6 minecraft:fern
setblock ~13 ~ ~6 minecraft:flowering_azalea
setblock ~14 ~ ~6 minecraft:large_fern[half=lower]
setblock ~14 ~1 ~6 minecraft:large_fern[half=upper]
setblock ~15 ~ ~6 minecraft:sweet_berry_bush[age=3]
setblock ~16 ~ ~6 minecraft:azalea
setblock ~17 ~ ~6 minecraft:fern
setblock ~18 ~ ~6 minecraft:lily_of_the_valley
summon minecraft:marker ~ ~ ~ {Tags:["sauna"]}
tellraw @s [{"text":"♨ ","color":"gold"},{"text":"Solaris Sauna built. Step inside, relax, and press the button by the stove.","color":"yellow"}]
