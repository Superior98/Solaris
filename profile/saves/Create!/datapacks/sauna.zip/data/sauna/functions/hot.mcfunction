execute if predicate sauna:c30 run particle minecraft:falling_water ~ ~1.7 ~ 0.25 0.15 0.25 0 1
title @s actionbar {"text":"♨ 85°C  ·  breathe in... and out...","color":"gold"}
effect give @s minecraft:resistance 4 0 true
