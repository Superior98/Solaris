tag @s remove sauna_in
stopsound @s record minecraft:music.overworld.cherry_grove
title @s actionbar {"text":"You feel wonderfully relaxed ☀","color":"yellow"}
effect give @s minecraft:speed 60 0 true
effect give @s minecraft:saturation 1 1 true
