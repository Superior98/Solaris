particle minecraft:cloud ~13 ~2.1 ~-3.5 0.45 0.05 0.2 0.005 1
execute if predicate sauna:c50 run particle minecraft:campfire_cosy_smoke ~13 ~2.2 ~-3.5 0.3 0 0.15 0.01 1
particle minecraft:white_ash ~15 ~2.5 ~0.5 2.5 1.5 4 0 3
execute if predicate sauna:c15 run particle minecraft:poof ~15 ~3.5 ~0.5 2 0.6 3 0.002 2
execute if predicate sauna:c30 run playsound minecraft:block.campfire.crackle block @a ~13 ~1.5 ~-3.5 0.7 0.9
execute if predicate sauna:c15 run playsound minecraft:block.fire.ambient block @a ~13 ~1.5 ~-3.5 0.35 0.7
execute if predicate sauna:c5 run playsound minecraft:block.pointed_dripstone.drip_water block @a ~15 ~4 ~0 0.6 1
execute if predicate sauna:c5 run playsound minecraft:block.amethyst_block.chime ambient @a ~6 ~3 ~0 0.4 0.7
execute if predicate sauna:c5 run playsound minecraft:block.water.ambient ambient @a ~9.5 ~0 ~3.5 0.25 1.2
execute if block ~14 ~1 ~-4 minecraft:spruce_button[powered=true] unless entity @s[tag=sauna_btn] run function sauna:loyly
execute unless block ~14 ~1 ~-4 minecraft:spruce_button[powered=true] run tag @s remove sauna_btn
execute positioned ~6 ~-1 ~-4 as @a[dx=11,dy=5,dz=8] run function sauna:inside
execute positioned ~12 ~-1 ~-4 as @a[dx=4,dy=5,dz=8] at @s run function sauna:hot
execute positioned ~6 ~-1 ~-4 as @a[dx=3,dy=5,dz=8] at @s run function sauna:lounge
execute positioned ~9 ~-2 ~3 as @a[dx=1,dy=1,dz=1] run function sauna:plunge
