schedule function sauna:loop 10t replace
