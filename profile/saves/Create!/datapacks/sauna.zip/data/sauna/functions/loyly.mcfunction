tag @s add sauna_btn
playsound minecraft:block.fire.extinguish block @a ~13 ~2 ~-3.5 1 0.7
playsound minecraft:block.lava.extinguish block @a ~13 ~2 ~-3.5 0.8 0.8
playsound minecraft:entity.generic.splash block @a ~13 ~2 ~-3.5 0.5 1.4
particle minecraft:splash ~13 ~2.2 ~-3.5 0.5 0.1 0.3 0.1 20
particle minecraft:cloud ~13 ~2.5 ~-3.5 0.6 0.4 0.4 0.06 50
particle minecraft:poof ~15 ~3 ~0.5 2.2 1.2 3.5 0.01 90
particle minecraft:campfire_cosy_smoke ~13 ~3 ~-3 1 0.5 1 0.01 12
execute positioned ~12 ~-1 ~-4 as @a[dx=4,dy=5,dz=8] run title @s actionbar {"text":"♨ Löyly! A soft wave of steam rolls over you ♨","color":"gold"}
execute positioned ~12 ~-1 ~-4 as @a[dx=4,dy=5,dz=8] run effect give @s minecraft:regeneration 12 1 true
execute positioned ~12 ~-1 ~-4 as @a[dx=4,dy=5,dz=8] run effect give @s minecraft:absorption 60 0 true
