tellraw @a {"text":"Clearing the forest for the beach...","color":"gold"}
fill 42 62 24 108 69 60 air replace #minecraft:logs
fill 42 70 24 108 77 60 air replace #minecraft:logs
fill 42 78 24 108 85 60 air replace #minecraft:logs
fill 42 86 24 108 93 60 air replace #minecraft:logs
fill 42 94 24 108 101 60 air replace #minecraft:logs
fill 42 102 24 108 109 60 air replace #minecraft:logs
fill 42 110 24 108 117 60 air replace #minecraft:logs
fill 42 118 24 108 125 60 air replace #minecraft:logs
fill 42 126 24 108 127 60 air replace #minecraft:logs
fill 42 62 24 108 69 60 air replace #minecraft:leaves
fill 42 70 24 108 77 60 air replace #minecraft:leaves
fill 42 78 24 108 85 60 air replace #minecraft:leaves
fill 42 86 24 108 93 60 air replace #minecraft:leaves
fill 42 94 24 108 101 60 air replace #minecraft:leaves
fill 42 102 24 108 109 60 air replace #minecraft:leaves
fill 42 110 24 108 117 60 air replace #minecraft:leaves
fill 42 118 24 108 125 60 air replace #minecraft:leaves
fill 42 126 24 108 127 60 air replace #minecraft:leaves
fill 42 62 24 108 69 60 air replace #minecraft:flowers
fill 42 70 24 108 77 60 air replace #minecraft:flowers
fill 42 78 24 108 85 60 air replace #minecraft:flowers
fill 42 86 24 108 93 60 air replace #minecraft:flowers
fill 42 94 24 108 101 60 air replace #minecraft:flowers
fill 42 102 24 108 109 60 air replace #minecraft:flowers
fill 42 110 24 108 117 60 air replace #minecraft:flowers
fill 42 118 24 108 125 60 air replace #minecraft:flowers
fill 42 126 24 108 127 60 air replace #minecraft:flowers
fill 42 62 24 108 69 60 air replace minecraft:grass
fill 42 70 24 108 77 60 air replace minecraft:grass
fill 42 78 24 108 85 60 air replace minecraft:grass
fill 42 86 24 108 93 60 air replace minecraft:grass
fill 42 94 24 108 101 60 air replace minecraft:grass
fill 42 102 24 108 109 60 air replace minecraft:grass
fill 42 110 24 108 117 60 air replace minecraft:grass
fill 42 118 24 108 125 60 air replace minecraft:grass
fill 42 126 24 108 127 60 air replace minecraft:grass
fill 42 62 24 108 69 60 air replace minecraft:tall_grass
fill 42 70 24 108 77 60 air replace minecraft:tall_grass
fill 42 78 24 108 85 60 air replace minecraft:tall_grass
fill 42 86 24 108 93 60 air replace minecraft:tall_grass
fill 42 94 24 108 101 60 air replace minecraft:tall_grass
fill 42 102 24 108 109 60 air replace minecraft:tall_grass
fill 42 110 24 108 117 60 air replace minecraft:tall_grass
fill 42 118 24 108 125 60 air replace minecraft:tall_grass
fill 42 126 24 108 127 60 air replace minecraft:tall_grass
fill 42 62 24 108 69 60 air replace minecraft:fern
fill 42 70 24 108 77 60 air replace minecraft:fern
fill 42 78 24 108 85 60 air replace minecraft:fern
fill 42 86 24 108 93 60 air replace minecraft:fern
fill 42 94 24 108 101 60 air replace minecraft:fern
fill 42 102 24 108 109 60 air replace minecraft:fern
fill 42 110 24 108 117 60 air replace minecraft:fern
fill 42 118 24 108 125 60 air replace minecraft:fern
fill 42 126 24 108 127 60 air replace minecraft:fern
fill 42 62 24 108 69 60 air replace minecraft:large_fern
fill 42 70 24 108 77 60 air replace minecraft:large_fern
fill 42 78 24 108 85 60 air replace minecraft:large_fern
fill 42 86 24 108 93 60 air replace minecraft:large_fern
fill 42 94 24 108 101 60 air replace minecraft:large_fern
fill 42 102 24 108 109 60 air replace minecraft:large_fern
fill 42 110 24 108 117 60 air replace minecraft:large_fern
fill 42 118 24 108 125 60 air replace minecraft:large_fern
fill 42 126 24 108 127 60 air replace minecraft:large_fern
fill 42 62 24 108 69 60 air replace minecraft:vine
fill 42 70 24 108 77 60 air replace minecraft:vine
fill 42 78 24 108 85 60 air replace minecraft:vine
fill 42 86 24 108 93 60 air replace minecraft:vine
fill 42 94 24 108 101 60 air replace minecraft:vine
fill 42 102 24 108 109 60 air replace minecraft:vine
fill 42 110 24 108 117 60 air replace minecraft:vine
fill 42 118 24 108 125 60 air replace minecraft:vine
fill 42 126 24 108 127 60 air replace minecraft:vine
fill 42 62 24 108 69 60 air replace minecraft:bee_nest
fill 42 70 24 108 77 60 air replace minecraft:bee_nest
fill 42 78 24 108 85 60 air replace minecraft:bee_nest
fill 42 86 24 108 93 60 air replace minecraft:bee_nest
fill 42 94 24 108 101 60 air replace minecraft:bee_nest
fill 42 102 24 108 109 60 air replace minecraft:bee_nest
fill 42 110 24 108 117 60 air replace minecraft:bee_nest
fill 42 118 24 108 125 60 air replace minecraft:bee_nest
fill 42 126 24 108 127 60 air replace minecraft:bee_nest
fill 42 62 24 108 69 60 air replace minecraft:sweet_berry_bush
fill 42 70 24 108 77 60 air replace minecraft:sweet_berry_bush
fill 42 78 24 108 85 60 air replace minecraft:sweet_berry_bush
fill 42 86 24 108 93 60 air replace minecraft:sweet_berry_bush
fill 42 94 24 108 101 60 air replace minecraft:sweet_berry_bush
fill 42 102 24 108 109 60 air replace minecraft:sweet_berry_bush
fill 42 110 24 108 117 60 air replace minecraft:sweet_berry_bush
fill 42 118 24 108 125 60 air replace minecraft:sweet_berry_bush
fill 42 126 24 108 127 60 air replace minecraft:sweet_berry_bush
fill 42 62 24 108 69 60 air replace minecraft:brown_mushroom
fill 42 70 24 108 77 60 air replace minecraft:brown_mushroom
fill 42 78 24 108 85 60 air replace minecraft:brown_mushroom
fill 42 86 24 108 93 60 air replace minecraft:brown_mushroom
fill 42 94 24 108 101 60 air replace minecraft:brown_mushroom
fill 42 102 24 108 109 60 air replace minecraft:brown_mushroom
fill 42 110 24 108 117 60 air replace minecraft:brown_mushroom
fill 42 118 24 108 125 60 air replace minecraft:brown_mushroom
fill 42 126 24 108 127 60 air replace minecraft:brown_mushroom
fill 42 62 24 108 69 60 air replace minecraft:red_mushroom
fill 42 70 24 108 77 60 air replace minecraft:red_mushroom
fill 42 78 24 108 85 60 air replace minecraft:red_mushroom
fill 42 86 24 108 93 60 air replace minecraft:red_mushroom
fill 42 94 24 108 101 60 air replace minecraft:red_mushroom
fill 42 102 24 108 109 60 air replace minecraft:red_mushroom
fill 42 110 24 108 117 60 air replace minecraft:red_mushroom
fill 42 118 24 108 125 60 air replace minecraft:red_mushroom
fill 42 126 24 108 127 60 air replace minecraft:red_mushroom
fill 42 62 24 108 69 60 air replace minecraft:moss_carpet
fill 42 70 24 108 77 60 air replace minecraft:moss_carpet
fill 42 78 24 108 85 60 air replace minecraft:moss_carpet
fill 42 86 24 108 93 60 air replace minecraft:moss_carpet
fill 42 94 24 108 101 60 air replace minecraft:moss_carpet
fill 42 102 24 108 109 60 air replace minecraft:moss_carpet
fill 42 110 24 108 117 60 air replace minecraft:moss_carpet
fill 42 118 24 108 125 60 air replace minecraft:moss_carpet
fill 42 126 24 108 127 60 air replace minecraft:moss_carpet
fill 42 72 24 86 81 60 air
fill 42 82 24 86 91 60 air
fill 42 92 24 86 101 60 air
fill 42 102 24 86 111 60 air
fill 42 112 24 86 121 60 air
fill 42 122 24 86 127 60 air
fill 42 66 24 86 70 60 dirt replace air
fill 42 71 24 86 71 60 grass_block replace air
fill 42 71 24 83 71 60 grass_block replace dirt
fill 42 71 24 83 71 60 grass_block replace stone
fill 42 71 24 83 71 60 grass_block replace andesite
fill 42 71 24 83 71 60 grass_block replace diorite
fill 42 71 24 83 71 60 grass_block replace granite
fill 42 71 24 83 71 60 grass_block replace gravel
fill 42 71 24 83 71 60 grass_block replace coal_ore
fill 42 71 24 83 71 60 grass_block replace iron_ore
fill 42 71 24 83 71 60 grass_block replace copper_ore
fill 42 71 24 83 71 60 grass_block replace create:zinc_ore
fill 42 71 24 83 71 60 grass_block replace tuff
fill 42 71 24 83 71 60 grass_block replace coarse_dirt
fill 42 71 24 83 71 60 grass_block replace podzol
fill 42 71 24 83 71 60 grass_block replace moss_block
fill 42 71 24 83 71 60 grass_block replace sand
fill 87 72 24 87 127 60 air
fill 87 68 24 87 71 60 sand
fill 88 71 24 88 127 60 air
fill 88 67 24 88 70 60 sand
fill 89 70 24 89 127 60 air
fill 89 66 24 89 69 60 sand
fill 90 70 24 90 127 60 air
fill 90 66 24 90 69 60 sand
fill 91 70 24 91 127 60 air
fill 91 66 24 91 69 60 sand
fill 92 69 24 92 127 60 air
fill 92 65 24 92 68 60 sand
fill 93 68 24 93 127 60 air
fill 93 64 24 93 67 60 sand
fill 94 68 24 94 127 60 air
fill 94 64 24 94 67 60 sand
fill 95 68 24 95 127 60 air
fill 95 64 24 95 67 60 sand
fill 96 67 24 96 127 60 air
fill 96 63 24 96 66 60 sand
fill 97 66 24 97 127 60 air
fill 97 62 24 97 65 60 sand
fill 98 66 24 98 127 60 air
fill 98 62 24 98 65 60 sand
fill 99 66 24 99 127 60 air
fill 99 62 24 99 65 60 sand
fill 100 65 24 100 127 60 air
fill 100 61 24 100 64 60 sand
fill 101 64 24 101 127 60 air
fill 101 60 24 101 63 60 sand
fill 102 64 24 102 127 60 air
fill 102 60 24 102 63 60 sand
fill 103 64 24 103 127 60 air
fill 103 60 24 103 63 60 sand
fill 104 63 24 104 127 60 air
fill 104 59 24 104 62 60 sand
fill 105 59 24 105 61 60 sand
fill 106 59 24 106 61 60 sand
fill 107 58 24 107 60 60 sand
fill 108 58 24 108 60 60 sand
fill 109 57 24 109 59 60 sand
fill 110 57 24 110 59 60 sand
fill 111 56 24 111 58 60 sand
fill 112 56 24 112 58 60 sand
fill 84 71 24 86 71 60 sand
tellraw @a {"text":"Beach ready! Build that bar :)","color":"yellow"}
