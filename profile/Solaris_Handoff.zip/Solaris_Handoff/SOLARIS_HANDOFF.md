# SOLARIS (formerly Fireheart City): Project Handoff, v1.7.0 (2026-09-28)

This file carries the project into a new chat. Read this file first. The older, much longer `Fireheart_Project_Handoff.md` in this folder has the full history, the toolchain derivation, the block-ID lists and the generator code from earlier sessions. Use it as a reference when you need detail.

## 1. The user
- **Who:** Daniel.
  - His Minecraft name is now **StellarFox1**. It was Fireheart_4743, and there's a new 256x256 HD skin.
  - He plays creatively and writes casually with typos, so read his messages for intent.
  - He wants short, professional replies, and code without comments unless they're needed.
  - Use the AskUserQuestion tool for big jobs; just do quick fixes.
- **His brother:**
  - Minecraft name **magmagamer9**; he joins through Essential (LAN-style multiplayer).
  - His house is at **x -67..-51, z 32..51**, front door at **-51 71 41/42** (facing west, onto the road at x -45).
  - It's decorated, and has a mailbox at **-46 71 39** (facing east).
- **City name:** **Solaris**. The apartment tower keeps the name "Ember Heights" and the sky island is "Neon Heights".
- **Apps:** SolPhone, SolFeed, SolTube, SolEats, SolTech, SolOS, SolNet, SolBeats, SolPad, SolWatch, SolStation, and SolBox (the console block).

## 2. Setup (paths)
- **Game:** Forge 1.20.1 (47.4.20), Modrinth App, profile **"Create_ Remastered"**, world **"Create!"**.
- **Profile folder:** `C:\Users\whosh\AppData\Roaming\ModrinthApp\profiles\Create_ Remastered\`
  - **Mod file:** `mods\fireheartcity-0.1.0.jar`. Keep this filename, and replace it only while the game is closed.
- **World datapacks:** `saves\Create!\datapacks\`.
  - `brohouse` (`/function brohouse:go` re-runs the brother-house decoration).
  - `statue` has no pack.mcmeta, so it's inactive. The statue is now built by the mod.
- **Voice:** `config\fireheartcity-voice.properties` holds the ElevenLabs key.
- **Device bridge:**
  - Remote-device tools: stage and commit files, computer use (javaw + Modrinth App), and sometimes `device_bash`.
  - The v1.7.0 jar **was copied into the mods folder** at the end of this session. The game must be restarted to load it.

## 3. Build and test (cloud workspace)
1. Unzip `fireheartcity_mod_source.zip` to `/tmp/modbuild`.
2. Rebuild the named jars and `cp.txt` as described in the old handoff, Part 7 (search "mkmap.py").
3. Run `bash build.sh`, which produces `fhc.jar`. It aborts on compile errors: never ship a failed build.
- **Compiling rules:**
  - Compile against Mojang-named jars; ART then reverses the jar to SRG.
  - Record accessors must use SRG names, e.g. `BlockStateParser.BlockResult.f_234748_()`.
  - Mixins use `remap=false` with SRG method names.
- **Test server:** `/tmp/srv`, scripts in `test_server_scripts/`.
  - `restart.sh [fresh]` copies `/mnt/user-data/uploads/Create!` (a staged copy of the world) as `world` and installs `fhc.jar`.
  - `./c.sh "cmd"` sends a command; output goes to `out.log`.
  - Re-apply forceloads after every restart: `-48 -40 48 112`, `-72 218 62 336`, `-30 -92 26 -28`, `41 -62 106 6`.
- **Useful commands:**
  - `/city test player`: 64 automated checks; all pass.
  - `/city ask <residentId> <text>`: prints the resident's reply. This is the best way to test dialogue.
  - `/city festival [start|stop|skip <ticks>]`
  - `/city mailtest <player>`: queues a letter with a gift plus a SolEats parcel.
  - `/city dump <from> <to>`, `/city dumpents`, `/city findblock <id>`
  - `/city surface <from> <to>`: writes `world/surface.txt` (x z y block) for map renders.
  - `/city skytower`

## 4. What changed this session (v1.7.0, commits in git log order)
### Fixes
- **Time:** the world had `doDaylightCycle=false`, which stopped the watch, the clock tower and the festival. `Events` now re-enables it every 10 s while config `timeMoves` is true.
- **Chat:** resident speech no longer goes to chat (`d.chatter` is forced false; speech bubbles only).
- **Vibrating residents:** fixed; the dance no longer snaps its angle every tick, and the shiver is a subtle occasional sway.
- **Factory door:** the Create piston contraption was lost. `AutoDoor` is now a code-driven sliding iron door at -3..-1 71..73 z12.
- **Factory worker:** fixes stalled or empty diesel engines through `Maintenance.fix` (with the wrench animation) and harvests and replants the wheat field. `Maintenance` also refreshes every diesel engine city-wide every 5 minutes.
- **Sky Launch:** duplicate tower at -61 156 removed. The tower was moved into the city at **98 71 -44**; the old one at -86 145 is removed when its chunk loads.

### Festival of the Founder
It now runs on its own timeline, so it works at any time of day.
- The stages are gather, sermon, chant, offerings, finale, then a **3-minute feast**:
  - cake stalls and lanterns;
  - a music loop;
  - residents dancing and eating;
  - fireworks every 30 s;
  - a hamper for the player and gifts from residents.
- Everything is cleaned up afterwards.

### Residents' intelligence
- **`Intents.meet`:** "meet me at <place> at <time>" in person, by text or on a call. The resident agrees, or counter-offers if they're working or asleep, then walks there and waits (`Meets.java`). They text when they arrive, greet the player and follow them. If stood up, they send a sad text and lose some trust.
- **`Intents.more`:** job, home, time, weather, directions, jokes, advice, feelings, insults and more.
- **`Understand.java` (large):**
  - Sentence patterns: do you like, what do you think of, have you ever, can you, would you, are you, did you, what is, where is, how many, how do, when, why, X or Y, and statements like I like / I built / I'm going to / my X is / I think / I have.
  - Opinions are stable per resident.
  - Follow-ups: why, what about you, really, same, tell me more.
  - It replaces the old "Interesting..." fallback with replies that echo the player's words.
- **`Knowledge.java`:** facts about Solaris places, gadgets, people, the Founder and magmagamer9.
- **Pets:** residents notice players' pets (name tag or animal type), fuss over them and talk about them.
- **Body language:** speech drives gestures (`Resident.emoteFor`), with expression particles per gesture.

### Rebrand
- **Solaris:** all display strings and app names renamed. `Rebrand.java` rewrites old names on signs chunk by chunk.
- **Statue:** rebuilt from the StellarFox1 HD skin by `statue_gen.py`, whose output lives in `res/data/fireheartcity/functions/statue/stellar1..2`. It runs once when its chunks load (`SkyTower.statue`, flag `statueV2`).

### Phone and tech
- **Real photos:**
  - Captured from the world render with no GUI (`ClientPhoto`), uploaded in chunks through the `PcNet.Blob` channel and stored in `<world>/fhc_photos/`.
  - Gallery keys are `ph_<id>`, fetched on demand by `PhotoCache`.
  - Captions when posting, a 3 s timer, and "set as wallpaper".
- **Video:** camera VIDEO mode records about 7 fps for up to 9 s as a 128x72 sprite sheet (`vd_<id>`, `ClientVideo`). Videos can be posted to SolFeed or **uploaded to SolTube** (`d.uploads`, action `tubeup`).
- **SolTube:** 3 new, richer premade videos (skyline day-to-night, festival highlights, ocean documentary). Uploads show in SolTube and play on TVs and in the cinema.
- **Settings:** wallpapers (8 painted presets or a photo), 24-hour clock, message previews, app labels.
- **App icons:** painted icons in `textures/gui/icons/*.png` (`AppIcons`).
- **Multiplayer:**
  - Other players appear in contacts as `player:<Name>`.
  - Texts go to their inbox and trigger a toast.
  - Live player-to-player calls with text lines (`PlayerLink.java`).
- **Headphones:**
  - They're an Equipable HEAD item with a 3D model (forge separate_transforms: 3D on the head, 2D icon in the GUI).
  - Right-click plays a two-hands put-on animation (`#deva|id|don`); music auto-plays while worn and stops when removed.
  - Sneak + right-click skips track.
- **TV:**
  - Everyone sees what's on it: `TvShows` (server) plus `TvRender` (client), which draws `GuiGraphics` into the world with depth testing.
  - Idle TVs show a "SolTV" channel.
  - The player holds a **SolTube Remote** while using a TV.
- **SolBox console block:**
  - Costs 150 at SolTech, the most expensive item.
  - Right-click needs a TV within 6 blocks. The camera turns to the TV, which plays a boot intro, then an animated menu with Snake, 2048, Flap, Mines, Blocks, SolTube and Photos.
  - The picture is on the world TV and visible to others; F toggles full screen.
  - The player holds a **SolBox Controller**.
- **SolEats overhaul:** shop cards with open/closed status and ratings, menus with item icons, a cart with quantities, a tip for Pip, and order tracking (preparing, out for delivery, at your door).

### Post
- **Mailbox block:** the owner is whoever places it. Every player gets one on first login.
- **Letters and gifts:** the postman walks to the player's mailbox, opens it, puts the post in with an animation and raises the flag. The player gets a toast.
- **SolEats orders:** left as a **delivery box block** beside the mailbox (at the front door). Right-click the box to open it.

### New blocks and items
- Ceiling lights (panel, round, spot, pendant; right-click toggles, light 15).
- Mailbox, delivery box, SolBox, remote, controller.

### Solaris East (island expansion)
- **Location:** x 41..106, z -62..6, built once via `Expansion.java` and `Builder.java`.
- **Road:** a new road (z -28..-24) links to the x=30 road by the library.
- **Buildings:**
  - **Police station:** x48..64 z-52..-34, with cells, desk, computers and a police car.
  - **Fire station:** x70..88 z-52..-34, with two fire trucks, fire pole, bunks and a siren bell.
  - **Research lab:** x46..62 z-20..-4.
    - Glowing froglight tubes and Create fluid tanks (lava/water) with pumps and pipes.
    - A water containment chamber with a conduit.
    - Brewing, cauldrons and computers.
  - **Cinema:** x68..96 z-21..2.
    - Marquee, lobby with snacks and tickets, red sofa rows (another_furniture) and curtains.
    - The **big screen** is drawn at x71..93 y73..81 z1.
    - It mirrors the projection-booth TV at **82 78 -16**; otherwise it runs a "Now Showing" schedule.
- **Places for residents:** police, fire, lab, cinema. The cinema is a hangout and date spot.

### Other additions
- **Hall of Lights:** on the Sky Organ bridge (x21..38 z282..288, floor y180). Walls and ceiling of redstone lamps glow around players, ripple waves with rising chimes play as they walk, and there's a finale at the organ end (`MusicHall.java`).
- **Parrots:** players' parrots dance while their owner listens to music, greet and flutter to them, and chirp with hearts. Sneak + right-click to pet. Client-side they bob and sway (`ParrotAnim`).
- **Brother's house:** decorated with rugs, ceiling lanterns, plants, a garden, a welcome sign, a parrot perch and a gift chest, via the `brohouse` datapack.

## 5. Key files (`src/com/fireheart/city/`)
- **Residents and dialogue:** Resident, Chat (dispatch), Intents, Understand, Knowledge, Meets, Pets, Festival, Work (jobs and tasks), Maintenance, AutoDoor, Post (+ MailboxBlock, ParcelBlock).
- **Phone and network:** Phones (texts and calls), PlayerLink, Photos, PcNet (network: Data/Msg/Act/Blob), Computers, Extras (phone actions, SolEats, gallery, settings), TvShows, TechStore, DeviceItem.
- **World building:** Expansion, Builder, MusicHall, SkyTower, Rebrand, ParrotLove, CeilingLightBlock, ConsoleBlock, TvBlock.
- **Client (`client/`, `client/pc/`):**
  - PhoneScreen, CameraApp, EatsApp, TubeApp, SettingsApp, Wallpapers, AppIcons, PhotoCache, ClientPhoto, ClientVideo, ConsoleScreen, ConsoleUi, TvRender, DeviceAnim, ParrotAnim.
  - ResidentModel/Renderer (gestures G_* 0..26).
- **Saved data:** CityData holds all flags: expanded, hallBuilt, statueV2, towerFixed, mailboxSetup, oldTowerGone, doorsMigrated.

## 6. Not done yet / next steps
1. **Check v1.7.0 in the real game:**
   - The jar is already in the mods folder; restart the game to load it. If needed, copy `fireheartcity-0.1.0.jar` from this folder over `mods\fireheartcity-0.1.0.jar` while the game is closed.
   - On first load:
     - The statue rebuilds.
     - Solaris East builds; it takes about 0.5 s, when the player is near x 70 z -30.
     - The Hall of Lights builds when the player is near the Sky Organ.
     - The brother's mailbox appears, and the old towers are removed.
   - Check each in-game.
2. **Mods not installed yet** (container network blocks Modrinth; install through the Modrinth App with computer use):
   - **WATERMeDIA:** needed for the cinema to play video files from his computer. Hook it into `TvRender.cinema()` / the booth TV program string (add e.g. `url;<path>`).
   - **Effortless Building:** no code conflicts expected. Mailboxes are claimed on first right-click even if Effortless skips `setPlacedBy`.
3. **Client-only features, not verified in the real client:** photo and video capture, TV/cinema world rendering, headphone 3D model, SolBox screen, parrot bob. Test them after installing, and watch `logs/latest.log` for errors from `TvRender`, `ClientPhoto` or `ClientVideo`.
4. **Ideas that came up:**
   - Police and fire staff jobs (new Job entries), so residents actually work in Solaris East.
   - Brother's own letters and SolEats to his mailbox (already works if he orders).
   - More premade films.

## 7. Contents of this handoff folder
- `SOLARIS_HANDOFF.md`: this file.
- `Fireheart_Project_Handoff.md`: the previous full handoff (history, toolchain, block IDs, generators).
- `fireheartcity-0.1.0.jar`: the v1.7.0 build, ready to install.
- `fireheartcity_mod_source.zip`: `src/`, `res/`, `build.sh`, `cp.txt`, `manifest.txt`, `mkmap.py`, `srg2named.srg`, `statue_gen.py`, `tools/`, plus the git history as `git.bundle`.
- `datapacks/brohouse/`: the brother-house decoration datapack.
- `test_server_scripts/`: `restart.sh`, `run.sh`, `c.sh`.
